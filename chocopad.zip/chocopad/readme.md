Chocopad
========

A 4x4 macropad keyboard using Kailh PG1350 Lower Profile Choc switches.

Keyboard Maintainer: Keebio  
Hardware Supported: Chocopad PCB, Arduino Pro Micro  
Hardware Availability: [Keebio](https://keeb.io)

Make example for this keyboard (after setting up your build environment):

    make keebio/chocopad:default

See [build environment setup](https://docs.qmk.fm/#/getting_started_build_tools) then the [make instructions](https://docs.qmk.fm/#/getting_started_make_guide) for more information.
